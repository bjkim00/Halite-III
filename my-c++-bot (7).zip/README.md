# Setting Up the C++ Starter Kit

    ./run_game.sh
    
This uses the included Makefile to build the sample bot and starter kit.

Linux users: if you're having problems running the bundled `halite` 
executable, you will probably want to build your own from source. Grab the 
source download from the Downloads page, extract it, and run `make` inside
the extracted directory. Then, move the built `halite` executable to this
directory. You will need GCC 7.2 or newer, but preferably the latest version
of GCC.
